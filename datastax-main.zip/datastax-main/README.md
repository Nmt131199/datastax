# ML Trained Model into an Rest API using Keras, FastAPI &amp; NoSQL 

